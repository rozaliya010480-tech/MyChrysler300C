package com.roman.mychrysler300c;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public class CarNotificationWorker extends Worker {
    public CarNotificationWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        NotificationHelper.show(
                getApplicationContext(),
                "Контроль Chrysler 300C",
                "Проверь пробег, задачи ТО, жидкости и запланированные работы по автомобилю.",
                3001
        );
        return Result.success();
    }
}