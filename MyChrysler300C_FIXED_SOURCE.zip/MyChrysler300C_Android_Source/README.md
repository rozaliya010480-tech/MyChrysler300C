# MyChrysler300C Android Source

Настоящий Android-проект для сборки APK.

Содержит:
- WebView-оболочку приложения Chrysler 300C.
- Локальное приложение из assets/index.html.
- Android-уведомления.
- WorkManager для фонового напоминания.